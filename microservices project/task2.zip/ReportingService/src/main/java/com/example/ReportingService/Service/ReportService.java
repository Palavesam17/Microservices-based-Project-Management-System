package com.example.ReportingService.Service;




import java.io.ByteArrayInputStream;
import java.util.List;

import com.example.ReportingService.Dto.ReportDTO;

public interface ReportService {
    ReportDTO createReport(ReportDTO dto);
    List<ReportDTO> getAllReports();
    ByteArrayInputStream exportReportsToExcel();
    ByteArrayInputStream exportReportsToPdf();
}
