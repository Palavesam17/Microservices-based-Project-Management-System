package com.example.ReportingService.Service;

import com.example.ReportingService.Dao.ReportRepository;
import com.example.ReportingService.Dto.ReportDTO;
import com.example.ReportingService.Entity.Report;
import com.example.ReportingService.Utill.ExcelReportGenerator;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;
import com.itextpdf.text.*;
import com.itextpdf.text.Font;
import com.itextpdf.text.pdf.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

@Service
public class ReportServiceImpl implements ReportService {

    private final ReportRepository reportRepository;

    public ReportServiceImpl(ReportRepository reportRepository) {
        this.reportRepository = reportRepository;
    }

    @Override
    public ReportDTO createReport(ReportDTO dto) {
        Report report = new Report(
            dto.getUserId(),
            dto.getTaskId(),
            dto.getTimeSpentHours(),
            dto.getProgressPercentage(),
            dto.getWorkloadLevel()
        );
        report = reportRepository.save(report);
        return new ReportDTO(report.getUserId(), report.getTaskId(), report.getTimeSpentHours(),
                             report.getProgressPercentage(), report.getWorkloadLevel());
    }

    @Override
    public List<ReportDTO> getAllReports() {
        List<Report> reports = reportRepository.findAll();
        List<ReportDTO> dtos = new ArrayList<>();
        for (Report r : reports) {
            dtos.add(new ReportDTO(r.getUserId(), r.getTaskId(), r.getTimeSpentHours(),
                                   r.getProgressPercentage(), r.getWorkloadLevel()));
        }
        return dtos;
    }

    @Override
    public ByteArrayInputStream exportReportsToExcel() {
        List<ReportDTO> reportList = getAllReports();
        return ExcelReportGenerator.generateExcel(reportList);
    }

    @Override
    public ByteArrayInputStream exportReportsToPdf() {
        Document document = new Document();
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        try {
            PdfWriter.getInstance(document, out);
            document.open();

            Font fontHeader = FontFactory.getFont(FontFactory.HELVETICA_BOLD);
            fontHeader.setSize(14);

            Paragraph title = new Paragraph("Reports", fontHeader);
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);
            document.add(Chunk.NEWLINE);

            PdfPTable table = new PdfPTable(6);
            table.setWidthPercentage(100);
            table.setWidths(new int[]{1, 2, 2, 3, 2, 2});

            Stream.of("ID", "User ID", "Task ID", "Time Spent (Hours)", "Progress (%)", "Workload Level")
                    .forEach(headerTitle -> {
                        PdfPCell header = new PdfPCell();
                        header.setBackgroundColor(BaseColor.LIGHT_GRAY);
                        header.setBorderWidth(2);
                        header.setPhrase(new Phrase(headerTitle));
                        table.addCell(header);
                    });

            List<Report> reports = reportRepository.findAll();
            for (Report report : reports) {
                table.addCell(String.valueOf(report.getId() != null ? report.getId() : 0));
                table.addCell(String.valueOf(report.getUserId()));
                table.addCell(String.valueOf(report.getTaskId()));
                table.addCell(String.valueOf(report.getTimeSpentHours()));
                table.addCell(String.valueOf(report.getProgressPercentage()));
                table.addCell(String.valueOf(report.getWorkloadLevel()));
            }

            document.add(table);
            document.close();

        } catch (DocumentException e) {
            throw new RuntimeException("Failed to export PDF: " + e.getMessage(), e);
        }

        return new ByteArrayInputStream(out.toByteArray());
    }
}
