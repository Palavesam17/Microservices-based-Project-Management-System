package com.example.ReportingService.Utill;



import com.example.ReportingService.Dto.ReportDTO;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.stream.Stream;

public class PdfReportGenerator {

    public static ByteArrayInputStream generatePdf(List<ReportDTO> reports) {
        Document document = new Document();
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        try {
            PdfWriter.getInstance(document, out);
            document.open();

            Font font = FontFactory.getFont(FontFactory.HELVETICA_BOLD);
            Paragraph title = new Paragraph("Report Summary", font);
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);
            document.add(Chunk.NEWLINE);

            PdfPTable table = new PdfPTable(5);
            Stream.of("User ID", "Task ID", "Time Spent", "Progress", "Workload")
                .forEach(headerTitle -> {
                    PdfPCell header = new PdfPCell();
                    header.setBackgroundColor(BaseColor.LIGHT_GRAY);
                    header.setPhrase(new Phrase(headerTitle));
                    table.addCell(header);
                });

            for (ReportDTO r : reports) {
                table.addCell(String.valueOf(r.getUserId()));
                table.addCell(String.valueOf(r.getTaskId()));
                table.addCell(String.valueOf(r.getTimeSpentHours()));
                table.addCell(String.valueOf(r.getProgressPercentage()));
                table.addCell(String.valueOf(r.getWorkloadLevel()));
            }

            document.add(table);
            document.close();

        } catch (DocumentException e) {
            throw new RuntimeException("Failed to generate PDF report: " + e.getMessage());
        }

        return new ByteArrayInputStream(out.toByteArray());
    }
}
