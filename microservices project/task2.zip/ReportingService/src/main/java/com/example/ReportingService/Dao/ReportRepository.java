package com.example.ReportingService.Dao;

import com.example.ReportingService.Entity.Report;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ReportRepository extends JpaRepository<Report, Long> {
}
