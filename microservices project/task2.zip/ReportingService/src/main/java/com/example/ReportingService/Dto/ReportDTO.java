package com.example.ReportingService.Dto;

public class ReportDTO {
	
	private Long userId;
    private Long taskId;
    private double timeSpentHours;
    private double progressPercentage;
    private int workloadLevel;

    public ReportDTO() {}

    public ReportDTO(Long userId, Long taskId, double timeSpentHours, double progressPercentage, int workloadLevel) {
        this.userId = userId;
        this.taskId = taskId;
        this.timeSpentHours = timeSpentHours;
        this.progressPercentage = progressPercentage;
        this.workloadLevel = workloadLevel;
    }
	
	
    public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getTaskId() {
		return taskId;
	}

	public void setTaskId(Long taskId) {
		this.taskId = taskId;
	}

	public double getTimeSpentHours() {
		return timeSpentHours;
	}

	public void setTimeSpentHours(double timeSpentHours) {
		this.timeSpentHours = timeSpentHours;
	}

	public double getProgressPercentage() {
		return progressPercentage;
	}

	public void setProgressPercentage(double progressPercentage) {
		this.progressPercentage = progressPercentage;
	}

	public int getWorkloadLevel() {
		return workloadLevel;
	}

	public void setWorkloadLevel(int workloadLevel) {
		this.workloadLevel = workloadLevel;
	}

	

    
}
