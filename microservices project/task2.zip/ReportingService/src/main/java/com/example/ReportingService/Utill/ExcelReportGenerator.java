package com.example.ReportingService.Utill;

import com.example.ReportingService.Dto.ReportDTO;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

public class ExcelReportGenerator {

    public static ByteArrayInputStream generateExcel(List<ReportDTO> reports) {
        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Sheet sheet = workbook.createSheet("Reports");

            // Header
            String[] columns = {"User ID", "Task ID", "Time Spent (hrs)", "Progress (%)", "Workload"};
            Row headerRow = sheet.createRow(0);
            for (int i = 0; i < columns.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(columns[i]);
            }

            // Data rows
            int rowIdx = 1;
            for (ReportDTO r : reports) {
                Row row = sheet.createRow(rowIdx++);
                row.createCell(0).setCellValue(r.getUserId());
                row.createCell(1).setCellValue(r.getTaskId());
                row.createCell(2).setCellValue(r.getTimeSpentHours());
                row.createCell(3).setCellValue(r.getProgressPercentage());
                row.createCell(4).setCellValue(r.getWorkloadLevel());
            }

            workbook.write(out);
            return new ByteArrayInputStream(out.toByteArray());
        } catch (IOException e) {
            throw new RuntimeException("Failed to generate Excel file: " + e.getMessage(), e);
        }
    }
}
