package com.example.userloginservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class UserloginserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserloginserviceApplication.class, args);
	}

}
