package com.example.userloginservice.Dao;



import org.springframework.data.jpa.repository.JpaRepository;

import com.example.userloginservice.Entity.User;

import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {
	 Optional<User> findByUsername(String username);
}
