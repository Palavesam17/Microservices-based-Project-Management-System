package com.example.userloginservice.Entity;

public enum Role {
    USER,
    ADMIN;

	
}
