package com.example.userloginservice.Dto;

import com.example.userloginservice.Entity.Role;
import java.util.Set;

public class RegisterRequest {
    private String username;
    private String password;
    private Set<Role> roles;

    public RegisterRequest() {}

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Set<Role> getRoles() {
        return roles;
    }

    public void setRoles(Set<Role> roles) {
        this.roles = roles;
    }
}
