package com.example.userloginservice.Controller;

import com.example.userloginservice.Config.JwtUtil;
import com.example.userloginservice.Dto.LoginRequest;
import com.example.userloginservice.Dto.RegisterRequest;
import com.example.userloginservice.Dto.UpdateUserRequest;
import com.example.userloginservice.Entity.Role;
import com.example.userloginservice.Entity.User;
import com.example.userloginservice.Service.CustomUserDetailsService;
import com.example.userloginservice.Service.TokenBlacklistService;
import com.example.userloginservice.Service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.*;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/auth")
public class AuthController {

    private final AuthenticationManager authManager;
    private final CustomUserDetailsService userDetailsService;
    private final JwtUtil jwtUtil;
    private final UserService userService;
    private final TokenBlacklistService tokenBlacklistService;

    public AuthController(AuthenticationManager authManager,
                          CustomUserDetailsService userDetailsService,
                          JwtUtil jwtUtil,
                          UserService userService,
                          TokenBlacklistService tokenBlacklistService) {
        this.authManager = authManager;
        this.userDetailsService = userDetailsService;
        this.jwtUtil = jwtUtil;
        this.userService = userService;
        this.tokenBlacklistService = tokenBlacklistService;
    }

    @PostMapping("/register")
    public User register(@RequestBody RegisterRequest request) {
        Set<Role> roles = new HashSet<>();
        roles.add(Role.USER); // default role
        return userService.registerUser(request.getUsername(), request.getPassword(), roles);
    }


    @PostMapping("/login")
    public Map<String, String> login(@RequestBody LoginRequest loginRequest) {
        authManager.authenticate(
            new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword())
        );
        UserDetails userDetails = userDetailsService.loadUserByUsername(loginRequest.getUsername());
        String token = jwtUtil.generateToken(userDetails);
        Map<String, String> map = new HashMap<>();
        map.put("token", token);
        return map;
    }


    @PostMapping("/logout")
    public ResponseEntity<String> logout(@RequestHeader("Authorization") String authHeader) {
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            String token = authHeader.substring(7);
            tokenBlacklistService.blacklistToken(token);
            return ResponseEntity.ok("Logout successful");
        } else {
            return ResponseEntity.badRequest().body("Invalid Authorization header");
        }
    }


    @PutMapping("/{id}")
    public User update(@PathVariable Long id, @RequestBody UpdateUserRequest request) {
        return userService.updateUser(id, request.getUsername(),request.getPassword(), request.getRoles());
    }


    @DeleteMapping("/{id}")
    public String delete(@PathVariable Long id) {
        userService.deleteUser(id);
        return "Deleted user with ID: " + id;
    }
}
