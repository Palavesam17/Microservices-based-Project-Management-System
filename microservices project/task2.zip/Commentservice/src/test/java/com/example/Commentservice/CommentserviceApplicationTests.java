package com.example.Commentservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommentserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
