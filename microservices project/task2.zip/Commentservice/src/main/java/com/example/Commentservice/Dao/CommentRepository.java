package com.example.Commentservice.Dao;


import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Commentservice.Entity.Comment;

import java.util.List;

public interface CommentRepository extends JpaRepository<Comment, Long> {
    List<Comment> findByTaskId(Long taskId);
    List<Comment> findByProjectId(Long projectId);
}

