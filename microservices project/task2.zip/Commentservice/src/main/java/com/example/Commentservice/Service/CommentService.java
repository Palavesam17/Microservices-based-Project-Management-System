package com.example.Commentservice.Service;


import java.util.List;


import com.example.Commentservice.Dto.CommentCreateDTO;
import com.example.Commentservice.Dto.CommentUpdateDTO;
import com.example.Commentservice.Entity.Comment;


public interface CommentService {
    
    Comment addComment(CommentCreateDTO dto);

    Comment updateComment(Long id, CommentUpdateDTO dto);

    void deleteComment(Long id);

    Comment getCommentById(Long id);

    List<Comment> getCommentsByTaskId(Long taskId);

    List<Comment> getCommentsByProjectId(Long projectId);
}
