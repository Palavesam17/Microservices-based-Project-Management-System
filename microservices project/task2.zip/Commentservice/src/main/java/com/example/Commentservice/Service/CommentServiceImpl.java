package com.example.Commentservice.Service;


import com.example.Commentservice.Dao.CommentRepository;
import com.example.Commentservice.Dto.CommentCreateDTO;
import com.example.Commentservice.Dto.CommentUpdateDTO;
import com.example.Commentservice.Entity.Comment;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CommentServiceImpl implements CommentService {

    @Autowired
    private CommentRepository commentRepository;

    // Create new comment
    @Override
    public Comment addComment(CommentCreateDTO dto) {
        Comment comment = new Comment();
        comment.setTaskId(dto.getTaskId());
        comment.setProjectId(dto.getProjectId());
        comment.setUserId(dto.getUserId());
        comment.setContent(dto.getContent());
        return commentRepository.save(comment);
    }

    // Update existing comment
    @Override
    public Comment updateComment(Long id, CommentUpdateDTO dto) {
        Optional<Comment> optionalComment = commentRepository.findById(id);
        if (!optionalComment.isPresent()) {
            throw new RuntimeException("Comment not found with id: " + id);
        }

        Comment comment = optionalComment.get();

        // Only update non-null fields
        if (dto.getTaskId() != null) {
            comment.setTaskId(dto.getTaskId());
        }
        if (dto.getProjectId() != null) {
            comment.setProjectId(dto.getProjectId());
        }
        if (dto.getUserId() != null) {
            comment.setUserId(dto.getUserId());
        }
        if (dto.getContent() != null && !dto.getContent().trim().isEmpty()) {
            comment.setContent(dto.getContent());
        }

        return commentRepository.save(comment);
    }

    // Delete comment
    @Override
    public void deleteComment(Long id) {
        if (!commentRepository.existsById(id)) {
            throw new RuntimeException("Comment not found with id: " + id);
        }
        commentRepository.deleteById(id);
    }

    // Get comment by ID
    @Override
    public Comment getCommentById(Long id) {
        return commentRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Comment not found with id: " + id));
    }

    // Get comments by Task ID
    @Override
    public List<Comment> getCommentsByTaskId(Long taskId) {
        return commentRepository.findByTaskId(taskId);
    }

    // Get comments by Project ID
    @Override
    public List<Comment> getCommentsByProjectId(Long projectId) {
        return commentRepository.findByProjectId(projectId);
    }
}
