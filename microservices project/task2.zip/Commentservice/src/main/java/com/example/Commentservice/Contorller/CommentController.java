package com.example.Commentservice.Contorller;

import com.example.Commentservice.Dto.CommentCreateDTO;
import com.example.Commentservice.Dto.CommentUpdateDTO;
import com.example.Commentservice.Entity.Comment;
import com.example.Commentservice.Service.CommentService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/comments")
public class CommentController {

    @Autowired
    private CommentService commentService;

    // ➕ Add a new comment
    @PostMapping
    public Comment addComment(@RequestBody CommentCreateDTO dto) {
        return commentService.addComment(dto);
    }

    // ✏️ Update an existing comment
    @PutMapping("/{id}")
    public Comment updateComment(@PathVariable Long id, @RequestBody CommentUpdateDTO dto) {
        return commentService.updateComment(id, dto);
    }

    // ❌ Delete a comment
    @DeleteMapping("/{id}")
    public void deleteComment(@PathVariable Long id) {
        commentService.deleteComment(id);
    }

    // 🔍 Get a single comment by ID
    @GetMapping("/{id}")
    public Comment getComment(@PathVariable Long id) {
        return commentService.getCommentById(id);
    }

    // 📄 Get all comments for a specific task
    @GetMapping("/task/{taskId}")
    public List<Comment> getCommentsByTask(@PathVariable Long taskId) {
        return commentService.getCommentsByTaskId(taskId);
    }

    // 📄 Get all comments for a specific project
    @GetMapping("/project/{projectId}")
    public List<Comment> getCommentsByProject(@PathVariable Long projectId) {
        return commentService.getCommentsByProjectId(projectId);
    }
}
