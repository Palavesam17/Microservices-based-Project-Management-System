package com.example.FileUploadService.Dto;

public class FileMetadataDTO {
    private String fileName;
    private String contentType;
    private Long size;

    public FileMetadataDTO() {}

    public FileMetadataDTO(String fileName, String contentType, Long size) {
        this.fileName = fileName;
        this.contentType = contentType;
        this.size = size;
    }

    public String getFileName() { return fileName; }
    public void setFileName(String fileName) { this.fileName = fileName; }

    public String getContentType() { return contentType; }
    public void setContentType(String contentType) { this.contentType = contentType; }

    public Long getSize() { return size; }
    public void setSize(Long size) { this.size = size; }
}
