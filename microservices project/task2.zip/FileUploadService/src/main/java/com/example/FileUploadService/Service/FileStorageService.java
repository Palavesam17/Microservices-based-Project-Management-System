package com.example.FileUploadService.Service;

import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface FileStorageService {
    String storeFile(MultipartFile file);
    Resource loadFile(String filename);
    List<String> listAllFiles();
}
