package com.example.NotificationService.Dto;



import java.time.LocalDateTime;

public class NotificationDTO {

    private Long userId;
    private String email;
    private String message;
    private boolean sent;
    private LocalDateTime createdAt;
    private LocalDateTime sentAt;

    public NotificationDTO() {
    }

    public NotificationDTO(Long userId, String email, String message, boolean sent, LocalDateTime createdAt, LocalDateTime sentAt) {
        this.userId = userId;
        this.email = email;
        this.message = message;
        this.sent = sent;
        this.createdAt = createdAt;
        this.sentAt = sentAt;
    }

    // Getters and setters
    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isSent() {
        return sent;
    }

    public void setSent(boolean sent) {
        this.sent = sent;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getSentAt() {
        return sentAt;
    }

    public void setSentAt(LocalDateTime sentAt) {
        this.sentAt = sentAt;
    }
}
