package com.example.NotificationService.Dao;


import org.springframework.data.jpa.repository.JpaRepository;

import com.example.NotificationService.Entity.Notification;

public interface NotificationRepository extends JpaRepository<Notification, Long> {
}
