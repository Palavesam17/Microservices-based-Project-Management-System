package com.example.NotificationService.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.NotificationService.Dto.NotificationDTO;
import com.example.NotificationService.Service.NotificationService;

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {

    @Autowired
    private NotificationService notificationService;

    @PostMapping("/send")
    public ResponseEntity<NotificationDTO> sendNotification(
            @RequestParam Long userId,
            @RequestParam String email,
            @RequestParam String message) {

        NotificationDTO notificationDTO = notificationService.sendNotification(userId, email, message);
        return ResponseEntity.ok(notificationDTO);
    }
}
