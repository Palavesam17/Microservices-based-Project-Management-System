package com.example.NotificationService.Service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.NotificationService.Dao.NotificationRepository;
import com.example.NotificationService.Dto.NotificationDTO;
import com.example.NotificationService.Entity.Notification;

import java.time.LocalDateTime;

@Service
public class NotificationService {

    @Autowired
    private NotificationRepository notificationRepository;

    // Simulate sending a notification
    public NotificationDTO sendNotification(Long userId, String email, String message) {
        Notification notification = new Notification();
        notification.setUserId(userId);
        notification.setEmail(email);
        notification.setMessage(message);
        notification.setSent(false);
        notification.setCreatedAt(LocalDateTime.now());

        Notification saved = notificationRepository.save(notification);

        // Simulate sending (just wait or log)
        simulateSendEmail(notification);

        saved.setSent(true);
        saved.setSentAt(LocalDateTime.now());

        Notification updated = notificationRepository.save(saved);

        return convertToDTO(updated);
    }

    private void simulateSendEmail(Notification notification) {
        // Here you could integrate SMTP later.
        System.out.println("Simulating sending email to " + notification.getEmail() + " with message: " + notification.getMessage());
        // For example, Thread.sleep(1000); to simulate delay, if needed
    }

    private NotificationDTO convertToDTO(Notification notification) {
        return new NotificationDTO(
                notification.getUserId(),
                notification.getEmail(),
                notification.getMessage(),
                notification.isSent(),
                notification.getCreatedAt(),
                notification.getSentAt()
        );
    }
}
