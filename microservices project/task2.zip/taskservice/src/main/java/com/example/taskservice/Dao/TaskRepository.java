package com.example.taskservice.Dao;


import org.springframework.data.jpa.repository.JpaRepository;

import com.example.taskservice.Entity.Task;

import java.util.List;

public interface TaskRepository extends JpaRepository<Task, Long> {
	List<Task> findByProjectId(Long projectId);

    List<Task> findByAssignedUserId(Long assignedUserId);


}

