package com.example.taskservice.Service;






import org.springframework.stereotype.Service;

import com.example.taskservice.Dao.TaskRepository;
import com.example.taskservice.Dto.AssignTaskRequest;
import com.example.taskservice.Dto.TaskRequest;
import com.example.taskservice.Entity.Task;

import java.util.List;
import java.util.Optional;

@Service
public class TaskService {

    private final TaskRepository taskRepository;

    public TaskService(TaskRepository taskRepository) {
        this.taskRepository = taskRepository;
    }
    
    public Task createTask(TaskRequest request) {
        Task task = new Task(
            null, // id (auto-generated)
            request.getTitle(),
            request.getDescription(),
            request.getPriority(),
            request.getStatus(),
            request.getDueDate(),
            null, // assignedUserId (can be set later via assign endpoint)
            request.getProjectId()
        );
        return taskRepository.save(task);
    }


    public Task getTaskById(Long id) {
        return taskRepository.findById(id).orElse(null);
    }

    public List<Task> getAllTasks() {
        return taskRepository.findAll();
    }

    public Task updateTask(Long id, TaskRequest request) {
        return taskRepository.findById(id).map(task -> {
            task.setTitle(request.getTitle());
            task.setDescription(request.getDescription());
            task.setPriority(request.getPriority());
            task.setStatus(request.getStatus());
            task.setDueDate(request.getDueDate());
            task.setProjectId(request.getProjectId());
            return taskRepository.save(task);
        }).orElseThrow(() -> new RuntimeException("Task not found"));
    }

    public void deleteTask(Long id) {
        taskRepository.deleteById(id);
    }

    public Task assignTask(Long taskId, AssignTaskRequest request) {
        Task task = taskRepository.findById(taskId)
                .orElseThrow(() -> new RuntimeException("Task not found"));

        task.setAssignedUserId(request.getAssignedUserId());
        return taskRepository.save(task);
    }


    public Task updateStatus(Long id, String status) {
        Task task = taskRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Task not found"));

        task.setStatus(status); // Directly using string or mapping to enum
        return taskRepository.save(task);
    }

}
