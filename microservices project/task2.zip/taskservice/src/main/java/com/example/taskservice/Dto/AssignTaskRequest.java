package com.example.taskservice.Dto;

import jakarta.validation.constraints.NotNull;

public class AssignTaskRequest {

    @NotNull(message = "Assigned user ID must not be null")
    private Long assignedUserId;

    public AssignTaskRequest() {}

    public AssignTaskRequest(Long assignedUserId) {
        this.assignedUserId = assignedUserId;
    }

    public Long getAssignedUserId() {
        return assignedUserId;
    }

    public void setAssignedUserId(Long assignedUserId) {
        this.assignedUserId = assignedUserId;
    }
}
