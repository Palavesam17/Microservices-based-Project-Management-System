package com.example.SearchService.Dao;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.SearchService.Entity.SearchItem;

import java.util.List;

public interface SearchItemRepository extends JpaRepository<SearchItem, Long> {

    @Query("SELECT s FROM SearchItem s WHERE LOWER(s.title) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
           "OR LOWER(s.description) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    List<SearchItem> searchByKeyword(String keyword);
}
