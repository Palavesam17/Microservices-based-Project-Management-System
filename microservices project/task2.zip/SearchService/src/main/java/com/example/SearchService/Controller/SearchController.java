package com.example.SearchService.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.SearchService.Dto.SearchItemDTO;
import com.example.SearchService.Service.SearchService;

import java.util.List;

@RestController
@RequestMapping("/api/search")
public class SearchController {

    private final SearchService service;

    @Autowired
    public SearchController(SearchService service) {
        this.service = service;
    }

    @GetMapping
    public List<SearchItemDTO> search(@RequestParam("keyword") String keyword) {
        return service.search(keyword);
    }

    @PostMapping
    public SearchItemDTO addItem(@RequestBody SearchItemDTO dto) {
        return service.save(dto);
    }
}
