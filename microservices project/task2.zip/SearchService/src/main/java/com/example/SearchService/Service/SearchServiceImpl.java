package com.example.SearchService.Service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SearchService.Dao.SearchItemRepository;
import com.example.SearchService.Dto.SearchItemDTO;
import com.example.SearchService.Entity.SearchItem;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class SearchServiceImpl implements SearchService {

    private final SearchItemRepository repository;

    @Autowired
    public SearchServiceImpl(SearchItemRepository repository) {
        this.repository = repository;
    }

    @Override
    public List<SearchItemDTO> search(String keyword) {
        List<SearchItem> items = repository.searchByKeyword(keyword);
        return items.stream()
                .map(item -> new SearchItemDTO(item.getId(), item.getTitle(), item.getDescription()))
                .collect(Collectors.toList());
    }

    @Override
    public SearchItemDTO save(SearchItemDTO dto) {
        SearchItem item = new SearchItem(dto.getTitle(), dto.getDescription());
        SearchItem saved = repository.save(item);
        return new SearchItemDTO(saved.getId(), saved.getTitle(), saved.getDescription());
    }

	
}
