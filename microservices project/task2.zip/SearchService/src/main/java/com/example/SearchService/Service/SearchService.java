package com.example.SearchService.Service;

import java.util.List;

import com.example.SearchService.Dto.SearchItemDTO;

public interface SearchService {
    List<SearchItemDTO> search(String keyword);
    SearchItemDTO save(SearchItemDTO dto);
}
