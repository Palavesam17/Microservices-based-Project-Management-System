package com.example.TagsService.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.TagsService.Dto.TagAssignmentDTO;
import com.example.TagsService.Dto.TagDTO;
import com.example.TagsService.Service.TagService;

import java.util.List;

@RestController
@RequestMapping("/api/tags")
public class TagController {

    private final TagService tagService;

    @Autowired
    public TagController(TagService tagService) {
        this.tagService = tagService;
    }

    @PostMapping
    public TagDTO createTag(@RequestParam String name) {
        return tagService.createTag(name);
    }

    @PostMapping("/assign")
    public ResponseEntity<String> assignTag(@RequestBody TagAssignmentDTO dto) {
        tagService.assignTag(dto);
        return ResponseEntity.ok("Tag assigned successfully.");
    }

    @GetMapping("/resource")
    public List<TagDTO> getTagsForResource(@RequestParam Long resourceId, @RequestParam String resourceType) {
        return tagService.getTagsForResource(resourceId, resourceType);
    }

    @GetMapping("/resources/by-tag")
    public List<Long> getResourcesByTag(@RequestParam Long tagId) {
        return tagService.getResourceIdsByTag(tagId);
    }
}
