package com.example.TagsService.Dto;

public class TagAssignmentDTO {
    private Long tagId;
    private Long resourceId;
    private String resourceType;

    public TagAssignmentDTO() {}

    public TagAssignmentDTO(Long tagId, Long resourceId, String resourceType) {
        this.tagId = tagId;
        this.resourceId = resourceId;
        this.resourceType = resourceType;
    }

    // Getters and Setters
    public Long getTagId() { return tagId; }

    public void setTagId(Long tagId) { this.tagId = tagId; }

    public Long getResourceId() { return resourceId; }

    public void setResourceId(Long resourceId) { this.resourceId = resourceId; }

    public String getResourceType() { return resourceType; }

    public void setResourceType(String resourceType) { this.resourceType = resourceType; }
}
