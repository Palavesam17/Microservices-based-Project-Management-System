package com.example.TagsService.Dao;



import org.springframework.data.jpa.repository.JpaRepository;

import com.example.TagsService.Entity.Tag;

import java.util.Optional;

public interface TagRepository extends JpaRepository<Tag, Long> {
    Optional<Tag> findByName(String name);
}
