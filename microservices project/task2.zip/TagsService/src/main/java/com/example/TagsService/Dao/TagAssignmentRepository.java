package com.example.TagsService.Dao;



import com.example.TagsService.Entity.TagAssignment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TagAssignmentRepository extends JpaRepository<TagAssignment, Long> {

    List<TagAssignment> findByResourceIdAndResourceType(Long resourceId, String resourceType);

    boolean existsByResourceIdAndResourceTypeAndTag_Id(Long resourceId, String resourceType, Long tagId);

    List<TagAssignment> findByTag_Id(Long tagId);
}
