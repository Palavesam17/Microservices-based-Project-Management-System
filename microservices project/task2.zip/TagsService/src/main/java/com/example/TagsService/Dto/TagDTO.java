package com.example.TagsService.Dto;

public class TagDTO {
    private Long id;
    private String name;

    public TagDTO() {}

    public TagDTO(Long id, String name) {
        this.id = id;
        this.name = name;
    }

    public Long getId() { return id; }

    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }

    public void setName(String name) { this.name = name; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TagDTO)) return false;
        TagDTO tagDTO = (TagDTO) o;
        return id != null && id.equals(tagDTO.id);
    }

    @Override
    public int hashCode() {
        return 31;
    }
}
