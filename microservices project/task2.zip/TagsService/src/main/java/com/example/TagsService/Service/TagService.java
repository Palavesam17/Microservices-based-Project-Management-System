package com.example.TagsService.Service;

import com.example.TagsService.Dao.TagAssignmentRepository;
import com.example.TagsService.Dao.TagRepository;
import com.example.TagsService.Dto.TagAssignmentDTO;
import com.example.TagsService.Dto.TagDTO;
import com.example.TagsService.Entity.Tag;
import com.example.TagsService.Entity.TagAssignment;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class TagService {

    private final TagRepository tagRepository;
    private final TagAssignmentRepository tagAssignmentRepository;

    @Autowired
    public TagService(TagRepository tagRepository, TagAssignmentRepository tagAssignmentRepository) {
        this.tagRepository = tagRepository;
        this.tagAssignmentRepository = tagAssignmentRepository;
    }

    public TagDTO createTag(String name) {
        Tag tag = new Tag(name);
        tagRepository.save(tag);
        return new TagDTO(tag.getId(), tag.getName());
    }

    public void assignTag(TagAssignmentDTO dto) {
        boolean exists = tagAssignmentRepository.existsByResourceIdAndResourceTypeAndTag_Id(
                dto.getResourceId(), dto.getResourceType(), dto.getTagId());

        if (!exists) {
            Tag tag = tagRepository.findById(dto.getTagId())
                    .orElseThrow(() -> new RuntimeException("Tag not found"));

            TagAssignment assignment = new TagAssignment(dto.getResourceId(), dto.getResourceType(), tag);
            tagAssignmentRepository.save(assignment);
        }
    }

    public List<TagDTO> getTagsForResource(Long resourceId, String resourceType) {
        List<TagAssignment> assignments = tagAssignmentRepository.findByResourceIdAndResourceType(resourceId, resourceType);
        return assignments.stream()
                .map(TagAssignment::getTag)
                .map(tag -> new TagDTO(tag.getId(), tag.getName()))
                .collect(Collectors.toList());
    }

    public List<Long> getResourceIdsByTag(Long tagId) {
        List<TagAssignment> assignments = tagAssignmentRepository.findByTag_Id(tagId);
        Set<Long> resourceIds = new HashSet<>();
        for (TagAssignment assignment : assignments) {
            resourceIds.add(assignment.getResourceId());
        }
        return new ArrayList<>(resourceIds);
    }
}
