package com.example.ActivityFeedService.Service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;

import com.example.ActivityFeedService.Dao.ActivityLogRepository;
import com.example.ActivityFeedService.Dto.ActivityLogDTO;
import com.example.ActivityFeedService.Entity.ActivityLog;

import java.time.LocalDateTime;
import java.util.stream.Collectors;

@Service
public class ActivityLogServiceImpl implements ActivityLogService {

    private final ActivityLogRepository repository;

    @Autowired
    public ActivityLogServiceImpl(ActivityLogRepository repository) {
        this.repository = repository;
    }

    @Override
    public ActivityLogDTO logAction(ActivityLogDTO dto) {
        ActivityLog log = new ActivityLog(
            dto.getAction(),
            dto.getEntityType(),
            dto.getEntityId(),
            dto.getPerformedBy(),
            LocalDateTime.now()
        );
        ActivityLog saved = repository.save(log);
        dto.setId(saved.getId());
        dto.setTimestamp(saved.getTimestamp());
        return dto;
    }

    @Override
    public Page<ActivityLogDTO> getAllLogs(Pageable pageable) {
        Page<ActivityLog> page = repository.findAll(pageable);
        return new PageImpl<>(
            page.getContent().stream().map(log ->
                new ActivityLogDTO(
                    log.getId(),
                    log.getAction(),
                    log.getEntityType(),
                    log.getEntityId(),
                    log.getPerformedBy(),
                    log.getTimestamp()
                )
            ).collect(Collectors.toList()),
            pageable,
            page.getTotalElements()
        );
    }

	
}
