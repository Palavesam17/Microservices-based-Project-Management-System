package com.example.ActivityFeedService.Service;


import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.example.ActivityFeedService.Dto.ActivityLogDTO;

public interface ActivityLogService {
    ActivityLogDTO logAction(ActivityLogDTO dto);
    Page<ActivityLogDTO> getAllLogs(Pageable pageable);
}
