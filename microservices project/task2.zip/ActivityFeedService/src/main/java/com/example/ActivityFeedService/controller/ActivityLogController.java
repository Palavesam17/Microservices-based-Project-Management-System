package com.example.ActivityFeedService.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.web.bind.annotation.*;

import com.example.ActivityFeedService.Dto.ActivityLogDTO;
import com.example.ActivityFeedService.Service.ActivityLogService;

@RestController
@RequestMapping("/api/activity")
public class ActivityLogController {

    private final ActivityLogService service;

    @Autowired
    public ActivityLogController(ActivityLogService service) {
        this.service = service;
    }

    @PostMapping("/log")
    public ActivityLogDTO logAction(@RequestBody ActivityLogDTO dto) {
        return service.logAction(dto);
    }

    @GetMapping("/logs")
    public Page<ActivityLogDTO> getAllLogs(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "timestamp") String sortBy,
            @RequestParam(defaultValue = "desc") String sortDir
    ) {
        Sort sort = sortDir.equalsIgnoreCase("asc") ? Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();
        Pageable pageable = PageRequest.of(page, size, sort);
        return service.getAllLogs(pageable);
    }
}
