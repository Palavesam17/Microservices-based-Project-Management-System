package com.example.Projectservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
