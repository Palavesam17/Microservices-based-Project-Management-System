package com.example.Projectservices.Dto;



import lombok.*;

import java.util.Set;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProjectResponseDTO {
    private Long id;
    private String name;
    private String description;
    private Set<Long> userIds;
    
    public ProjectResponseDTO() {
    }

    // All-args constructor
    public ProjectResponseDTO(Long id, String name, String description, Set<Long> userIds) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.userIds = userIds;
    }
    
    public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Set<Long> getUserIds() {
		return userIds;
	}
	public void setUserIds(Set<Long> userIds) {
		this.userIds = userIds;
	}
	
}
