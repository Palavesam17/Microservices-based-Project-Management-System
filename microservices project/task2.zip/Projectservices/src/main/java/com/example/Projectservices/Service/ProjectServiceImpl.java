package com.example.Projectservices.Service;

import com.example.Projectservices.Dto.ProjectRequestDTO;
import com.example.Projectservices.Dto.ProjectResponseDTO;
import com.example.Projectservices.Dto.AssignUsersDTO;
import com.example.Projectservices.Entity.Project;
import com.example.Projectservices.Repository.ProjectRepository;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProjectServiceImpl implements ProjectService {

    private final ProjectRepository projectRepository;

    // Manual constructor for dependency injection
    public ProjectServiceImpl(ProjectRepository projectRepository) {
        this.projectRepository = projectRepository;
    }

    @Override
    public ProjectResponseDTO createProject(ProjectRequestDTO dto) {
        // Create new Project entity object
        Project project = new Project();
        
        // Set fields from DTO
        project.setName(dto.getName());
        project.setDescription(dto.getDescription());
        
        // Save project entity to database
        Project savedProject = projectRepository.save(project);
        
        // Map saved project entity to response DTO and return
        return mapToDTO(savedProject);
    }

    @Override
    public ProjectResponseDTO updateProject(Long id, ProjectRequestDTO dto) {
        Project project = projectRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Project not found with id: " + id));
        project.setName(dto.getName());
        project.setDescription(dto.getDescription());
        project = projectRepository.save(project);
        return mapToDTO(project);
    }

    @Override
    public void deleteProject(Long id) {
        if (!projectRepository.existsById(id)) {
            throw new ResourceNotFoundException("Project not found with id: " + id);
        }
        projectRepository.deleteById(id);
    }

    @Override
    public ProjectResponseDTO assignUsers(Long id, AssignUsersDTO dto) {
        Project project = projectRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Project not found with id: " + id));
        if (dto.getUserIds() != null) {
            project.getUserIds().addAll(dto.getUserIds());
        }
        project = projectRepository.save(project);
        return mapToDTO(project);
    }

    @Override
    public List<ProjectResponseDTO> getAllProjects() {
        return projectRepository.findAll()
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public ProjectResponseDTO getProjectById(Long id) {
        Project project = projectRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Project not found with id: " + id));
        return mapToDTO(project);
    }

    private ProjectResponseDTO mapToDTO(Project project) {
        ProjectResponseDTO dto = new ProjectResponseDTO();
        dto.setId(project.getId());
        dto.setName(project.getName());
        dto.setDescription(project.getDescription());
        dto.setUserIds(project.getUserIds() != null ? project.getUserIds() : new HashSet<>());
        return dto;
    }

}
