package com.example.Projectservices.Dto;


import lombok.*;

import java.util.Set;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProjectRequestDTO {
	private String name;
    private String description;
    
    public ProjectRequestDTO() {
    }

    // All-args constructor
    public ProjectRequestDTO(String name, String description) {
        this.name = name;
        this.description = description;
    }
	
    public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
}
