package com.example.Projectservices.Repository;




import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Projectservices.Entity.Project;

public interface ProjectRepository extends JpaRepository<Project, Long> {
}
