package com.example.Projectservices.Dto;




import lombok.*;

import java.util.Set;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AssignUsersDTO {
    private Set<Long> userIds;
    
    public AssignUsersDTO() {
    }

    public AssignUsersDTO(Set<Long> userIds) {
        this.userIds = userIds;
    }
    

	public Set<Long> getUserIds() {
		return userIds;
	}

	public void setUserIds(Set<Long> userIds) {
		this.userIds = userIds;
	}
}
