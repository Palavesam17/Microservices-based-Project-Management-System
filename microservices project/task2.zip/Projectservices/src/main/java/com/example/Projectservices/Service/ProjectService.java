package com.example.Projectservices.Service;



import com.example.Projectservices.Dto.ProjectRequestDTO;
import com.example.Projectservices.Dto.ProjectResponseDTO;
import com.example.Projectservices.Dto.AssignUsersDTO;

import java.util.List;

public interface ProjectService {

    ProjectResponseDTO createProject(ProjectRequestDTO dto);

    ProjectResponseDTO updateProject(Long id, ProjectRequestDTO dto);

    void deleteProject(Long id);

    ProjectResponseDTO assignUsers(Long id, AssignUsersDTO dto);

    List<ProjectResponseDTO> getAllProjects();

    ProjectResponseDTO getProjectById(Long id);
}
