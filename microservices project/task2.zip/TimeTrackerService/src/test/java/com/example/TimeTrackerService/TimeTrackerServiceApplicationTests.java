package com.example.TimeTrackerService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TimeTrackerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
