package com.example.TimeTrackerService.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.TimeTrackerService.Dto.TimeEntryDTO;
import com.example.TimeTrackerService.Service.TimeEntryService;

@RestController
@RequestMapping("/api/timers")
public class TimeEntryController {

    @Autowired
    private TimeEntryService timeEntryService;

    @PostMapping("/start")
    public ResponseEntity<TimeEntryDTO> startTimer(@RequestParam Long userId, @RequestParam Long taskId) {
        TimeEntryDTO timeEntry = timeEntryService.startTimer(userId, taskId);
        return ResponseEntity.ok(timeEntry);
    }

    @PostMapping("/stop")
    public ResponseEntity<?> stopTimer(@RequestParam Long userId, @RequestParam Long taskId) {
        try {
            TimeEntryDTO timeEntry = timeEntryService.stopTimer(userId, taskId);
            return ResponseEntity.ok(timeEntry);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
