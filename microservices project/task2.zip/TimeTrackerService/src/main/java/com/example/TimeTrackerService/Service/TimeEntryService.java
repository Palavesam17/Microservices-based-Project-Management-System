package com.example.TimeTrackerService.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.TimeTrackerService.Dao.TimeEntryRepository;
import com.example.TimeTrackerService.Dto.TimeEntryDTO;
import com.example.TimeTrackerService.Entity.TimeEntry;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class TimeEntryService {

    @Autowired
    private TimeEntryRepository timeEntryRepository;

    public TimeEntryDTO startTimer(Long userId, Long taskId) {
        TimeEntry entry = new TimeEntry(userId, taskId, LocalDateTime.now());
        TimeEntry saved = timeEntryRepository.save(entry);
        return convertToDTO(saved);
    }

    public TimeEntryDTO stopTimer(Long userId, Long taskId) throws Exception {
        Optional<TimeEntry> optionalEntry = timeEntryRepository.findTopByUserIdAndTaskIdAndEndTimeIsNullOrderByStartTimeDesc(userId, taskId);
        if (optionalEntry.isEmpty()) {
            throw new Exception("No active timer found for this user and task");
        }

        TimeEntry entry = optionalEntry.get();
        LocalDateTime endTime = LocalDateTime.now();
        entry.setEndTime(endTime);

        Duration duration = Duration.between(entry.getStartTime(), endTime);
        entry.setDurationInSeconds(duration.getSeconds());

        TimeEntry updated = timeEntryRepository.save(entry);
        return convertToDTO(updated);
    }

    private TimeEntryDTO convertToDTO(TimeEntry entry) {
        return new TimeEntryDTO(
                entry.getUserId(),
                entry.getTaskId(),
                entry.getStartTime(),
                entry.getEndTime(),
                entry.getDurationInSeconds()
        );
    }
}
