package com.example.TimeTrackerService.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.TimeTrackerService.Entity.TimeEntry;

import java.util.Optional;

public interface TimeEntryRepository extends JpaRepository<TimeEntry, Long> {
    Optional<TimeEntry> findTopByUserIdAndTaskIdAndEndTimeIsNullOrderByStartTimeDesc(Long userId, Long taskId);
}
