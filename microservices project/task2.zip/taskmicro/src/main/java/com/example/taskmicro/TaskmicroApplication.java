package com.example.taskmicro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
@EnableEurekaServer
public class TaskmicroApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskmicroApplication.class, args);
	}

	
}
