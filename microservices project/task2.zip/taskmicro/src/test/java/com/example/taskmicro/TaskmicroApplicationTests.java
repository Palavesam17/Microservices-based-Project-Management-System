package com.example.taskmicro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskmicroApplicationTests {

	@Test
	void contextLoads() {
	}

}
